/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

/**
 *
 * @author MABOW
 */
public class Task {

    private String taskName;
    private String taskDescription;
    private int taskNumber;
    private String developerDetails;
    private int taskDuration;
    private String taskId;
    private String taskStatus;

    private static int TASK_COUNT = 0;
    private static int TOTAL_HOURS = 0;

    public Task(String taskName, String taskDescription, String developerDetails, int taskDuration,  String taskStatus) {
        this.taskName = taskName;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;    
        this.taskStatus = taskStatus;
        this.taskNumber = TASK_COUNT;
        
        TASK_COUNT++;
        TOTAL_HOURS += taskDuration;        
        taskId = createTaskID();
        
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getTaskDescription() {
        return taskDescription;
    }

    public void setTaskDescription(String taskDescription) {
        this.taskDescription = taskDescription;
    }

    public int getTaskNumber() {
        return taskNumber;
    }


    public String getDeveloperDetails() {
        return developerDetails;
    }

    public void setDeveloperDetails(String developerDetails) {
        this.developerDetails = developerDetails;
    }

    public int getTaskDuration() {
        return taskDuration;
    }

    public void setTaskDuration(int taskDuration) {
        this.taskDuration = taskDuration;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getTaskStatus() {
        return taskStatus;
    }

    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus;
    }

    public boolean checkTaskDescription() {
        return taskDescription != null
                && taskDescription.length() > 0
                && taskDescription.length() <= 50;
    }

    public final String createTaskID() {
        return taskName.substring(0, 2).toUpperCase() + ":" + taskNumber + ":"
                + developerDetails.substring(developerDetails.length() - 3).toUpperCase();

    }

    public String printTaskDetails() {
        return taskStatus + "," + developerDetails + "," + taskNumber + ","
                + taskName + "," + taskDescription + "," + taskId + "," + taskDuration;
    }

    public int returnTotalHours() {
        return TOTAL_HOURS;
    }

}
