/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.main;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author MABOW
 */
public class Main {
    
    private final Login login = new Login();
    private List<Task> taskList = null;

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int menuOption = -1;

        boolean exit = false;
        Main main = new Main();
        while (!exit) {

            System.out.println("Welcome, Select Menu Option\n"
                    + "1 - Regisiter\n2 - Login\n0 - Exit");

            menuOption = scan.nextInt();

            switch (menuOption) {
                case 0:
                    exit = true;
                    System.out.println("System Exiting. Goodbye");
                    break;
                case 1:
                    main.register();
                    break;
                case 2:
                    main.login();
                    break;

                default:
                    System.out.println("Incorrect menu option, please see menu.");
                    break;
            }
        }

    }

    public void register() {

        System.out.println("REGISTRATION\n#################################");
        Scanner scan = new Scanner(System.in);

        System.out.println("Please enter Username");
        String username = scan.nextLine();

        System.out.println("Please enter Password");
        String password = scan.nextLine();

        System.out.println("Enter First Name");
        String firstName = scan.nextLine();

        System.out.println("Enter Last Name");
        String lastName = scan.nextLine();

        User user = new User(username, password, firstName, lastName);
        String response = login.registerUser(user);
        System.out.println(response);
    }

    public void login() {

        System.out.println("LOGIN\n####################################");
        Scanner scan = new Scanner(System.in);

        System.out.println("Enter Username");
        String username = scan.nextLine();

        System.out.println("Enter Password");
        String password = scan.nextLine();

        User user = login.loginUser(username, password) ? login.getUser(username) : null;

        if (user != null) {
            System.out.println("Welcome " + user.getFirstName() + " , " + user.getLastName() + " it is great to see you again.");
            taskMenu();
        } else {
            System.out.println("Username or password incorrect, please try again");
        }
    }

    private void taskMenu() {
        if (taskList == null) {
            taskList = new ArrayList<>();
        }

        System.out.println("\nWelcome to EasyKanban\n");
        Scanner scan = new Scanner(System.in);

        int menuOption = -1;

        while (true) {

            System.out.println("Select Menu Option\n"
                    + "1 - Add Tasks\n2 - Show report\n3 - Quit");

            menuOption = scan.nextInt();

            switch (menuOption) {

                case 1:
                    addTasksOption();
                    break;
                case 2:
                    System.out.println("Comming Soon");
                    break;
                case 3:
                    System.out.println("System Exiting. Goodbye");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Incorrect menu option, please see menu.");
                    break;
            }
        }

    }

    private void addTasksOption() {

        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter task name.");
        String taskName = scan.nextLine();

        System.out.println("Please enter task description.");
        String taskDescription = scan.nextLine();

        System.out.println("Please enter developer details( firstname and last name)");
        String developerDetails = scan.nextLine();

        System.out.println("Please enter task duration(in hours)");
        int taskDuration = scan.nextInt();

        String taskStatus = "";
        boolean exitStatus = false;

        while (!exitStatus) {
            System.out.println("Please select task status from below options.");
            System.out.println("1 -  To do\n2 - Doing\n3 - Done.");
            int statusOption = scan.nextInt();

            switch (statusOption) {
                case 1:
                    taskStatus = "To Do";
                    exitStatus = true;
                    break;
                case 2:
                    taskStatus = "Doing";
                    exitStatus = true;
                    break;
                case 3:
                    taskStatus = "Done";
                    exitStatus = true;
                    break;
                default:
                    System.out.println("Incorrect menu option, please see menu.");
                    break;

            }

        }

        Task task = new Task(taskName, taskDescription, developerDetails, taskDuration, taskStatus);
        taskList.add(task);

        System.out.println(task.printTaskDetails());
        System.out.println("Total hours: " + task.returnTotalHours());

    }

}
