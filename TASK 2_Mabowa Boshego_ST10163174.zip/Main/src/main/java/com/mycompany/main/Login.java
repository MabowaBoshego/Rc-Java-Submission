/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 *
 * @author MABOW
 */
public class Login {

    private final List<User> registeredUserList;

    public Login() {
        registeredUserList = new ArrayList<>();
    }

    public boolean checkUserName(String username) {
        return username != null
                && username.length() > 1
                && username.length() <= 5
                && username.contains("_");
    }

    public boolean checkPasswordComplexity(String password) {

        if (password != null && password.length() >= 8) {

            Pattern letter = Pattern.compile("[a-zA-z]");
            Pattern digit = Pattern.compile("[0-9]");
            Pattern special = Pattern.compile("[!@#$%&*()_+=|<>?{}\\[\\]~-]");

            Matcher hasLetter = letter.matcher(password);
            Matcher hasDigit = digit.matcher(password);
            Matcher hasSpecial = special.matcher(password);

            return hasLetter.find() && hasDigit.find() && hasSpecial.find();

        }
        return false;
    }

    public String registerUser(User user) {

        if (!checkUserName(user.getUsername())) {
            return "Username is not correctly formatted, please ensure"
                    + " that your username contains an underscore and is no"
                    + " more than 5 characters in length.";

        }

        if (!checkPasswordComplexity(user.getPassword())) {
            return "Password is not correctly formatted,"
                    + " please ensure that the password contains at least 8"
                    + " characters, a capital letter, a number and a"
                    + " special character";
        }

        registeredUserList.add(user);
        return "User successfully registered.";
    }

    public boolean loginUser(String username, String password) {
        User user = registeredUserList.stream()
                .filter(u -> u.getUsername().equalsIgnoreCase(username) && u.getPassword().equals(password))
                .findFirst().orElse(null);

        return user != null;
    }

    public String loginStatus(String username, String password) {
        
        if (loginUser(username, password)) {
            User user = getUser(username);
            return "Welcome " + user.getFirstName() + " , " + user.getLastName() + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again";
        }

    }

    public User getUser(String username) {
        return registeredUserList.stream()
                .filter(u -> u.getUsername().equalsIgnoreCase(username))
                .findFirst().orElse(null);
    }
}
